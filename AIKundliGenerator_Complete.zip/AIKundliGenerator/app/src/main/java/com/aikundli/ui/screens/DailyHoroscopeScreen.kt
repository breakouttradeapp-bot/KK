package com.aikundli.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aikundli.model.ZodiacHoroscope
import com.aikundli.ui.components.GlassCard
import com.aikundli.ui.theme.*

@Composable
fun DailyHoroscopeScreen(
    navController: NavController
) {
    var selected by remember { mutableStateOf<ZodiacHoroscope?>(null) }
    val horoscopes = remember { defaultZodiacList() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DarkSpace, DeepIndigo, Color(0xFF120025))))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier          = Modifier.fillMaxWidth().padding(16.dp).padding(top = 44.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Default.ArrowBack, null, tint = GoldenStar)
                }
                Column {
                    Text("Daily Horoscope",
                        style      = MaterialTheme.typography.headlineMedium,
                        color      = GoldenStar,
                        fontWeight = FontWeight.Bold)
                    Text("Tap your sign for today's reading",
                        color = StarlightWhite.copy(0.5f),
                        style = MaterialTheme.typography.bodySmall)
                }
            }

            // Grid of signs
            LazyVerticalGrid(
                columns               = GridCells.Fixed(3),
                contentPadding        = PaddingValues(16.dp),
                verticalArrangement   = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier              = Modifier.weight(1f)
            ) {
                itemsIndexed(horoscopes) { index, sign ->
                    ZodiacCard(
                        sign    = sign,
                        delay   = index * 55,
                        selected = selected?.sign == sign.sign,
                        onClick = { selected = if (selected?.sign == sign.sign) null else sign }
                    )
                }
            }
        }

        // Detail overlay
        AnimatedVisibility(
            visible = selected != null,
            enter   = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit    = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            selected?.let { sign ->
                SignDetailCard(sign = sign, onClose = { selected = null })
            }
        }
    }
}

@Composable
fun SignDetailCard(sign: ZodiacHoroscope, onClose: () -> Unit) {
    val gradientColors = zodiacGradient(sign.sign)
    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        shape    = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp, bottomStart = 16.dp, bottomEnd = 16.dp),
        colors   = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(gradientColors.first, gradientColors.second, DeepIndigo))
                )
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(sign.symbol, fontSize = 40.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(sign.sign,
                                style      = MaterialTheme.typography.headlineMedium,
                                color      = Color.White,
                                fontWeight = FontWeight.Bold)
                            Text("Today's Cosmic Forecast",
                                color = Color.White.copy(0.6f),
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, null, tint = Color.White.copy(0.7f))
                    }
                }

                Spacer(Modifier.height(16.dp))

                Text(sign.text,
                    color  = Color.White.copy(0.9f),
                    style  = MaterialTheme.typography.bodyLarge,
                    lineHeight = 24.sp)

                Spacer(Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    LuckyChip("🔢 ${sign.luckyNumber}", "Lucky Number")
                    LuckyChip("🎨 ${sign.luckyColor}", "Lucky Color")
                }
            }
        }
    }
}

@Composable
fun LuckyChip(value: String, label: String) {
    Column(
        modifier            = Modifier
            .background(Color.White.copy(0.12f), RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = GoldenStar, fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyLarge)
        Text(label, color = Color.White.copy(0.6f),
            style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun ZodiacCard(sign: ZodiacHoroscope, delay: Int, selected: Boolean, onClick: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(delay.toLong())
        visible = true
    }
    val scale by animateFloatAsState(
        targetValue   = when { !visible -> 0.7f; selected -> 1.06f; else -> 1f },
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label         = "zscale"
    )
    val alpha by animateFloatAsState(
        targetValue   = if (visible) 1f else 0f,
        animationSpec = tween(300),
        label         = "zalpha"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "zCard")
    val glow by infiniteTransition.animateFloat(
        initialValue  = 0.6f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(tween(1800 + delay, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label         = "zglow"
    )

    val colors = zodiacGradient(sign.sign)

    Card(
        onClick = onClick,
        modifier = Modifier.aspectRatio(0.88f).scale(scale).alpha(alpha),
        shape  = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) GoldenStar else GlassBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (selected) 12.dp else 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(colors.first.copy(0.3f + glow * 0.1f), colors.second.copy(0.15f))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier            = Modifier.padding(8.dp)
            ) {
                Text(sign.symbol,
                    fontSize = 30.sp,
                    modifier = Modifier.scale(if (selected) glow else 1f))
                Spacer(Modifier.height(6.dp))
                Text(sign.sign,
                    color      = if (selected) GoldenStar else StarlightWhite,
                    fontWeight = FontWeight.Bold,
                    style      = MaterialTheme.typography.labelSmall,
                    textAlign  = TextAlign.Center)
                Text("🔢 ${sign.luckyNumber}",
                    color = GoldenStar.copy(0.7f),
                    style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun zodiacGradient(sign: String): Pair<Color, Color> = when (sign) {
    "Aries"       -> Color(0xFFFF5722) to Color(0xFFE91E63)
    "Taurus"      -> Color(0xFF4CAF50) to Color(0xFF2196F3)
    "Gemini"      -> Color(0xFFFFD700) to Color(0xFFFF9800)
    "Cancer"      -> Color(0xFF9C27B0) to Color(0xFF3F51B5)
    "Leo"         -> Color(0xFFFF9800) to Color(0xFFFF5722)
    "Virgo"       -> Color(0xFF009688) to Color(0xFF4CAF50)
    "Libra"       -> Color(0xFFE91E63) to Color(0xFF9C27B0)
    "Scorpio"     -> Color(0xFF8B0000) to Color(0xFF6A0572)
    "Sagittarius" -> Color(0xFF1565C0) to Color(0xFF9C27B0)
    "Capricorn"   -> Color(0xFF37474F) to Color(0xFF1565C0)
    "Aquarius"    -> Color(0xFF1976D2) to Color(0xFF00BCD4)
    "Pisces"      -> Color(0xFF5C6BC0) to Color(0xFF00BCD4)
    else          -> Color(0xFF6A0572) to Color(0xFF1565C0)
}

fun defaultZodiacList(): List<ZodiacHoroscope> = listOf(
    ZodiacHoroscope("Aries",       "♈", "Fiery energy ignites bold opportunities. Trust your instincts today — the stars favor decisive action and leadership.", 9,  "Red"),
    ZodiacHoroscope("Taurus",      "♉", "Stability grounds your day beautifully. Focus on what brings lasting comfort, and your efforts will yield rich rewards.", 6,  "Green"),
    ZodiacHoroscope("Gemini",      "♊", "Communication flows with brilliant clarity. Your words carry cosmic power — share your ideas and watch connections flourish.", 5,  "Yellow"),
    ZodiacHoroscope("Cancer",      "♋", "Emotional depth creates meaningful bonds today. Your intuition is your greatest guide — trust the quiet voice within.", 2,  "Silver"),
    ZodiacHoroscope("Leo",         "♌", "Your natural charisma radiates magnificently. Step into the spotlight with confidence — the universe applauds your brilliance.", 1,  "Gold"),
    ZodiacHoroscope("Virgo",       "♍", "Meticulous attention to detail leads to remarkable achievements. Your precision transforms ordinary tasks into masterpieces today.", 4,  "Navy"),
    ZodiacHoroscope("Libra",       "♎", "Harmony and beauty elevate every interaction. Your diplomatic gifts resolve conflicts and bring elegant solutions to complex situations.", 7,  "Pink"),
    ZodiacHoroscope("Scorpio",     "♏", "Profound transformation unlocks powerful insights. Embrace the deep currents of change — they carry you toward your highest self.", 8,  "Crimson"),
    ZodiacHoroscope("Sagittarius", "♐", "Adventure and wisdom call with irresistible force. Expand your horizons fearlessly — the cosmos rewards your philosophical quest.", 3,  "Purple"),
    ZodiacHoroscope("Capricorn",   "♑", "Disciplined effort yields extraordinary results today. Your mountain-climbing spirit conquers obstacles with graceful determination.", 10, "Brown"),
    ZodiacHoroscope("Aquarius",    "♒", "Innovation and originality set you brilliantly apart. Your visionary ideas can genuinely change the world — share them boldly.", 11, "Electric Blue"),
    ZodiacHoroscope("Pisces",      "♓", "Intuition and creativity flow like a sacred river. Your dreaming mind holds the keys to beautiful solutions today.", 12, "Sea Green"),
)
